lines = open("./27/H1_11_A.txt", "r").readlines()[1:]

sum_big = 0
sum_small = 0

min_diff_big_chet_sm_nechet = [999_999_999, 0,0]
min_diff_big_nechet_sm_chet = [999_999_999, 0,0]
min_diff_big_nechet_sm_nechet = [999_999_999, 0,0]

for line in lines:
    a,b = list(map(int, line.split()))

    if a % 2 == 0:
        continue
    
    big = max(a,b)
    small = min(a,b)
    
    
