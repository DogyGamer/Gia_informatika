lines = open("./27/H1_9_B.txt", "r").readlines()[1:]


S = 0
n_chet = 0
n_nechet = 0

mind_diff = 999_999_999

for line in lines:
    a,b = list(map(int, line.split()))
    
    c = max(a,b)
    if c % 2 == 0:
        n_chet += 1
    else:
        n_nechet += 1
        
    if a % 2 != b % 2:
        mind_diff = min(mind_diff, max(a,b) - min(a,b))
    
    S += c
    
if n_chet > n_nechet:
    if S % 2 != 0:
        S -= mind_diff
else:
    if S % 2 == 0:
        S -= mind_diff
        
print(n_chet, n_nechet, S%2 == 0)
print(S)

# Нипон, первое сошлось, второе чуть-чуть отличается